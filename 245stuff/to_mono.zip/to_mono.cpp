#include <iostream>
#include <vector>
#include <fstream>

#include <string>
#include <algorithm>
#include <cmath>
#include <cstring>


struct WavHeader
{
  char name[4];//always says "RIFF"
  unsigned filesize;// we can check for validity but eh
  char filetype[4];//always says "WAVE"
  char fmt[4];//always says "fmt"
  unsigned formatDataLen; // always = 16 ?
  unsigned short formatType; //should be 1
  unsigned short numChannels; // this is important!!!
  unsigned sampleRate; // this is important!!!
  unsigned bytesPerSecond;//bytesPerSample*channels
  unsigned short bytesPerSample;// channel count * (bits per sample/8)
  unsigned short bitsPerSample;//this is important !!!
  char dataHeader[4];//always says "data"
  unsigned dataSize;// this is important!!!
};

template<typename T>
T clamp(T in, T minimum, T maximum)
{
  if(maximum < minimum)
  {
    std::swap(maximum, minimum);
  }
  if(in > maximum)
  {
    in = maximum;
  }
  if(in < minimum)
  {
    in = minimum;
  }
  return in;
}

int main(int argc, char** argv)
{
  if(argc != 3)
  {
    std::cout << "incorrect arguments, please use the following input:\n to_mono.exe <filename> <decibels>\n";
  }
  else
  {
    std::string filename = argv[1];
    float decibelLevel = std::atof(argv[2]);
    
    std::string wavFileData;

    std::fstream inputFile(filename.c_str(), std::ios_base::binary | std::ios_base::in);
    int stride;
    int bitsPerSample;
    WavHeader inputHeader;
    if(inputFile.is_open())
    {
      inputFile.read((char*)&inputHeader, sizeof(WavHeader));
      bitsPerSample = inputHeader.bitsPerSample;// / inputHeader.numChannels;
      stride = (inputHeader.bitsPerSample / 8)*inputHeader.numChannels;
      std::vector<unsigned char> inputData;
      
      inputData.resize(inputHeader.dataSize);
      inputFile.read((char*)&inputData[0], inputHeader.dataSize);


      float DCOffset = 0;

      float largestAbsVal = 0;
      std::vector<float> inputSamples;
      for(int i = 0; i < inputData.size(); i += stride)
      {
        int leftVal = 0;
        int rightVal = 0;
        if(bitsPerSample == 8)
        {
          leftVal = (unsigned char)inputData[i];
          if(inputHeader.numChannels == 2)
          {
            rightVal = (unsigned char)inputData[i+1];
            rightVal -= 128;
          }
          leftVal -= 128;

          
        }
        else if(bitsPerSample == 16)
        {
          leftVal = *((short*)&inputData[i]);
          if(inputHeader.numChannels == 2)
          {
            rightVal = *((short*) &inputData[i+2]);
          }
        }
        float monoSample = leftVal;
        if(inputHeader.numChannels == 2)
        {
          monoSample += rightVal;
          monoSample /= 2.0f;
        }

        inputSamples.push_back(monoSample);
        
        
        DCOffset += monoSample;
      }
      DCOffset /= inputSamples.size();

      for(int i = 0; i < inputSamples.size(); ++i)
      {
        inputSamples[i] -= DCOffset;
        if(std::abs(inputSamples[i]) > largestAbsVal)
        {
          largestAbsVal = std::abs(inputSamples[i]);
        }
      }

      
      
      float rescaleVal = std::pow(10.0f, decibelLevel / 20.0f);
      if(bitsPerSample == 8)
      {
        rescaleVal *= 127;

      }
      else if(bitsPerSample == 16)
      {
        rescaleVal *= 32767;
      }
      
      float mScalar = rescaleVal / ((float)largestAbsVal);
      for(int i = 0; i < inputSamples.size(); ++i)
      {
        
        inputSamples[i] *= mScalar;
        if(bitsPerSample == 8)
        {
          inputSamples[i] += 128;
          inputSamples[i] = clamp(inputSamples[i], 0.0f, 255.0f);
        }
        else if(bitsPerSample == 16)
        {
          //necessary because we used ints for scaling
          inputSamples[i] = clamp(inputSamples[i], -32768.0f, 32767.0f);
        }
        
      }

      WavHeader newHeader = inputHeader;
      newHeader.numChannels = 1;
      
      
      //take the stride to mono as well
      //stride /= inputHeader.numChannels;
      //it'll still be 1 or 2

      std::vector<char> outputData;
      for(int i = 0; i < inputSamples.size(); ++i)
      {
        if(bitsPerSample == 8)
        {
          //write as char
          char toOut = static_cast<char>(inputSamples[i]);
          outputData.push_back(toOut);
        }
        else if(bitsPerSample == 16)
        {
          //write as 2 chars
          short ourData = short(inputSamples[i]);
          char toOut[2];
          memcpy(&toOut, &ourData, sizeof(short));
          outputData.push_back(toOut[0]);
          outputData.push_back(toOut[1]);
        }
      }

      newHeader.bytesPerSample = newHeader.numChannels * (newHeader.bitsPerSample/8);
      newHeader.bytesPerSecond = newHeader.bytesPerSample * newHeader.sampleRate;

      newHeader.dataSize = outputData.size();
      newHeader.filesize = newHeader.dataSize + 36;
      std::fstream outputFile("to_mono.wav", std::ios_base::binary | std::ios_base::out);
      if(outputFile.is_open())
      {
        outputFile.write((char*)&newHeader, sizeof(newHeader));
        outputFile.write(&outputData[0], outputData.size());
        outputFile.close();
      }
      else
      {
        std::cout << "Couldn't create output file. Permissions?";
      }

    }
    else
    {
      std::cout << "Invalid filename, no output.";
    }



    
  }
  
}